Dependencies

flask
d3.js
python 2.7
sklearn

Introduction
Set the variable DATA_PATH to the data in app_194.py and in playerRegression.py under NBAVisualization

Start the program by running the command “python app_194.py”
You can then select clustering or regression, and try out different parameters!

One nice example with Player Clustering is:
	First Stat: FT
	Second Stat: PF
	Response: Salary
	Season: 2013-2014
	Position: PG
	Clusters: 5